package com.cg.lesson8;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExpTest {
	public static void main(String[] args) {
		String inputStr = "Test String"; 
		String pattern = "Test String"; 
		boolean patternMatched = Pattern.matches(pattern, inputStr);          
		System.out.println(patternMatched); 
		
		System.out.println("------------------");
		String input = "Shop,Mop,Hopping,Chopping"; 
		Pattern pattern1 = Pattern.compile("hop"); 
		Matcher matcher = pattern1.matcher(input); 
		System.out.println(matcher.matches()); 
		while (matcher.find()){ 
			System.out.println(matcher.group() + ": " 
					+matcher.start() + ": " + matcher.end()); 
			} 
		
		System.out.println("------------------------");
		
		String input1 = "Exo1";
		 //Checks for string that start with upper case alphabet and end with digit. 
		Pattern p = Pattern.compile("^[A-Z][0-9]$"); 
		Matcher m = p.matcher(input1); 
		if (!m.find()) { 
			System.err.println("Enter  code which  start with upper case alphabet"+
					" and end with a digit"); 
		} 
		else {
			System.out.println("String is correct "+ m.group() + " start "+m.start()+
								" end "+m.end());
		}
	}
}
