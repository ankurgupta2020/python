package com.cg.lesson8;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input="Today is 7th Feb 2020";
		
		String ss[]=input.split("\\s");  // split with white space
		
		for(String s:ss)
		{
			System.out.println(s);
			System.out.println("Matching with 'is' "+s.matches("is"));
			System.out.println("Matching with digit "+s.matches("\\d+"));
			System.out.println("--------");
		}
	}

}
