txns and custs are datasets files  
commands.txt file contains the commands. 