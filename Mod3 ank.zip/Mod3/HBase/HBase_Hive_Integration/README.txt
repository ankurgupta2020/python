Step-1 : Load data in RDD
Step-2 : Define parsing logic
Step-3 Define schema  
Step-4 : combine output of Step -2 and Schema
Step-5 Convert output of Step-4 in DataSet or DataFrame
Step-6 Define Table/ View on DataSet or DataFrame
Step-7 write SQL
Step-8 Display output / Save output 