A) Create Database

Create database test;

B) Create Database if not exists 

Create database IF NOT EXISTS test;

C) Describe database 

describe database test;

D) Add comment with database definition 

Create database IF NOT EXISTS test1 COMMENT 'sampletable' ;

E) Describe database 

describe database test1;

F)Print current database name 

set hive.cli.print.current.db=true;

G) Create database at another location (Not in default location) 

Create database IF NOT EXISTS test2 LOCATION '/user/sample/hive/';


-------------------------------------------


I) DROP Database

Drop database test1;

Drop database IF EXISTS test1;

Drop database IF EXISTS test1 CASCADE;

-----------------------------------------------------------------------
J) Create table

use test;

K) 
create table transactions1 (tid int, tdate date,amount int,Country String,
State varchar(25),City char(20))
row format delimited
fields terminated by ',';

L)
 show tables;

M)
 describe transactions1;

N)
 load data local inpath '/home/cloudera/hive/txns' 
overwrite into table transactions1;

O)
 select tdate from transactions limit 2;
=============================================================
select year(tdate) from transactions limit 2;

select month(tdate) from transactions limit 2;

select day(tdate) from transactions limit 2;

select hour(tdate) from transactions limit 2;

select weekofyear(tdate) from transactions limit 2;


P) date and timestamp

select current_date();
select current_timestamp();
select date_add(current_date(),2);

-------Temporary Table ---------

Q) Temporary table concept is available in Hive from 0.14.0 version onwards

Temporary tables are used to store output of complex queries

Hive automatically deletes Temporary tables at the end of session

Hive stores Temporary table’s data in user’s scratch directory 
rather than hive warehouse directory

The scratch directory works as the data 
Sandbox for the user and the default location for 
scratch directory is   /tmp/hive/<username>

 

R) 
create TEMPORARY table transactions1 (tid int,
 tdate date,amount int,Country String,State varchar(25),
 City char(20))
row format delimited
fields terminated by ',';

Note: Multiple hive users can
 create same named temporary table at
 same time because the scope of temporary table is within session.


Note: We can’t create PARTITIONING and INDEXES in temporary table

Note: If a user creates a temporary table and a 
Permanent table already exists with the same name 
then user can access only Temporary table in that session.
 To access permanent table user has to DROP or RENAME Temporary table.

S)
create TEMPORARY table transactions (tid int, tdate date,
amount int,Country String,State varchar(25),City char(20))
row format delimited
fields terminated by ',';

show tables;

select * from transactions;

drop table transactions;
select * from transactions;


-------- EXTRENAL TABLE -------------------

For External table, hive just manages
 metadata means hive doesn’t manage the storage (data).

Note: If we drop any external table then hive just drop structure of the table.

Note: We can define external table on the data that is stored in HDFS

T) 
hadoop fs -mkdir /user/data
hadoop fs -put path/emp1 /user/data/emp

U)
use test;

V)
create external table emp (eid int, ename string,sal int, deptno int)
row format delimited
fields terminated by ','
location '/user/data';

W)
drop table emp;

x.) check data file: 

hadoop fs -ls /user/data




