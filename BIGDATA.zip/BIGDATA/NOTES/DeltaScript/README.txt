Script.sql file contains Hive script which we need to run 

data files : customer1, customer2

customer1 data file we got on day1 of the business 
customer2 data file we got on day2 of the business 