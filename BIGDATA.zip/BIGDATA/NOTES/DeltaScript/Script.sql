Data flow in Datalake in Hadoop Project

Source(Mysql) -> Ingestion tool(SQOOP) -> staging layer (database in hive) -> ETL logic (Spark/Pig/HQL/MapReduce,etc) -> datastore layer (database in hive)

-- staging table is truncate and load type table means whenever we load the data in staging , we truncate the previous data 
-- As staging table is external type so we can't run truncate , so we will run hadoop fs -rm on file 

create database if not exists staging location '/user/cloudera/poc/staging.db';

create database if not exists datastore location '/user/cloudera/poc/datastore.db';

use staging;

create external table customers (customer_id string,
 name string, state string,
 city string, entry_date string)
row format delimited
fields terminated by ','
location '/user/cloudera/poc/staging.db/customers' ;

use datastore;

create external table datastore.customers_history (customer_id string,
 name string, state string, city string,entry_date string)
partitioned by (load_date string)
row format delimited
fields terminated by ','
location '/user/cloudera/poc/datastore.db/customers_history' ;

load  data local inpath 'path/delta/customer1' into table  staging.customers;

set hive.exec.dynamic.partition.mode=nonstrict;

insert into datastore.customers_history partition(load_date)
select *, current_date() as load_date  from staging.customers
distribute by load_date;


select * from staging.customers;

select * from datastore.customers_history;
show partitions datastore.customers_history;

show partitions datastore.customers_history;

Note - truncate staging table before the next load:
hadoop fs -rm /user/cloudera/poc/retail_staging.db/customers/*       

*/Note -  load new file in staging 
load  data local inpath 'path/delta/customer2' into table  staging.customers;

select * from staging.customers;

Note- compare staging with latest partition in datastore table 

insert into  datastore.customers_history partition(load_date)
select u.customer_id , u.name , u.state , u.city , u.entry_date, date_add(current_date(),1) as load_date
from
(select *, row_number() over (partition by t.customer_id order by t.entry_date desc) as row_num  from (
select *,'' as load_date  from staging.customers
union all
select * from datastore.customers_history)t)u
where u.row_num = 1
distribute by load_date;

show partitions datastore.customers_history;





