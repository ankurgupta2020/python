echo "I am in shell script"
export runtime=`date -u +"%Y%m%d%H%M%S"`
export log_file=/home/cloudera/Desktop/customers_$runtime.log
exec $> ${log_file}
hive -f /home/cloudera/Desktop/sample.hql
echo " I am back in shell script"
