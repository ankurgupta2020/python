print ("Enter your name")
name=input()
print("Hello! ",name)