print("enter first name")
firstname=input()
lastname=input("enter last name")
wholename=firstname+"."+ lastname
print (wholename)