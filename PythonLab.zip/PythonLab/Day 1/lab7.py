slist=[10,20,30,40]
n=input("Enter a number ")
b=False
for x in range(len(slist)):
  if int(n)==slist[x]:
    b=True
    break
print(b)