hist=[]
n=int(input("Number of elements"))
for i in range(n):
  num=int(input())
  hist.append(num)
for i in range(n):
  for j in range(hist[i]):
    print("*",end="")
  print("")