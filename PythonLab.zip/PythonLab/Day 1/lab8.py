l1=[10,20,30,40,50]
l2=[5,10,15,20]
flag=0
b=False
for i in range(len(l1)):
  for j in range(len(l2)):
    if l1[i]==l2[j]:
      b=True
      flag=1
  if flag==1:
    break
print(b)