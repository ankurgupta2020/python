nlist=[1,2,3,4,5,6,7,8,9,10]
sum=0
mul=1
for i in range(len(nlist)):
  sum=sum+nlist[i]
  mul=mul*nlist[i]
print("sum = ",sum)
print ("product = ",mul)
