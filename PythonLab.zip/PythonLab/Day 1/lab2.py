print ("Enter 2 numbers")
n1=int(input())
n2=int(input())
sum=n1+n2
if sum > 0:
  print("sum is " +str(sum)+" and it is positive")
else:
  print("sum is " +str(sum)+" and it is negative")
  