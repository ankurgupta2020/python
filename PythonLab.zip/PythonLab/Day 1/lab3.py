cn="32"
print("The correct number is 32. enter 32")
n1=input() 
while (n1 != "32"):
  print("The correct number is 32. enter 32")
  n1=input()