str1="Sit on a potato pan, Otis"
str1=str1.replace(",","")
str1=str1.replace(" ","")
str1=str1.replace("!","")
str1=str1.replace("-","")
str1=str1.replace("?","")
str1=str1.replace("/","")
str1=str1.replace("%","")
str1=str1.replace("%","")
str1=str1.replace(".","")
str1=str1.replace("'","")
str1=str1.replace('"','')
s=""
for i in str1:
  s=i+s
print(str1)
print(s)
str1=str1.lower()
s=s.lower()
if s==str1:
  print("Panlindrome")
else:
  print("Not Panlindrome")