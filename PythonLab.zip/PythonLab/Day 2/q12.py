import datetime
class Date:
	def d1(self):
		x = datetime.datetime.now()
		print(x)
	

class UseDate:
	p1=Date()
	p1.d1()