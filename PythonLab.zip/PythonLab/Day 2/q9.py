'''
Cdict = {
'a': 0, 'c': 0, 'b': 0, 'e': 0, 'd': 0, 'g': 0, 'f': 0, 'i': 0, 'h': 0, 'k': 0,
 'j': 0, 'm': 0, 'l': 0, 'o': 0, 'n': 0, 'q': 0, 'p': 0, 's': 0, 'r': 0, 'u': 0,
 't': 0, 'w': 0, 'v': 0, 'y': 0, 'x': 0, 'z': 0}




def freq(s):
  s=s.lower()
  for i in s:
    #keys=Cdict.keys()
    #if i in keys:
    Cdict[i] += 1
  return Cdict

print(freq("aabbccdd"))
'''

cdic={}
def freq(s):
	s=s.lower()
	for i in range(len(s)):
		if s[i] in cdic.keys():
			cdic[s[i]] += 1
		else:
			cdic[s[i]] = 1
	return cdic
print(freq("aabbccdd"))