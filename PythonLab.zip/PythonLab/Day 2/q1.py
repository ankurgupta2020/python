def generate_n_chars(n,c):
   print(n*c)
generate_n_chars(7,"a")
