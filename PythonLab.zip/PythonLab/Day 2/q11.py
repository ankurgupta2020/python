import lab19 as a

lst=[1,2,3,4,5]
lst2=[1,2,3,4,5]

print(a.add(lst))
print(a.sub(lst))
print(a.mul(lst))
print(a.add2(lst,lst2))
print(a.sub2(lst,lst2))
print(a.mul2(lst,lst2))