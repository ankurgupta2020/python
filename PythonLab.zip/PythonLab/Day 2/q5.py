def filter_long_words(n,words):
  l1=[]
  print("Number : " +str(n))
  for i in range(len(words)-1):
    if len(words[i])>n:
      l1.append(words[i])
  print(l1)
num=input("enter word length")

list1=["red","orange","purple","maroon","green"]
filter_long_words(int(num),list1)