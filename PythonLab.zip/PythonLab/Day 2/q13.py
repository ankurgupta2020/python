f1=open('a.txt','r')
f2=open('b.txt','w')
line1=f1.readlines();
for x in line1:
	f2.write(x)
f1.close()
f2.close()