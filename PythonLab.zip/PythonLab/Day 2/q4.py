list1=["red","orange","purple","maroon","green"]
list2=[]
for i in range(len(list1)):
  n=len(list1[i])
  list2.append(n)
print (list1)
print (list2)
max=max(list2)
print("max= ",max)