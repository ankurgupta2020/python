def maxInList(*l):
  max=l[0]
  for i in range(1,len(l)):
    if(max < l[i]):
      max=l[i]
  print("max = ",max)
maxInList(62,45,98,67,19,398,370)