def add(lst):
	sum=0
	for i in range(len(lst)):
		sum=sum+lst[i]
	return sum

def sub(lst):
	diff=lst[0]
	for i in range(1,len(lst)):
		diff=diff-lst[i]
	return diff

def mul(lst):
	mulp=1
	for i in range(len(lst)):
		mulp=mulp*lst[i]
	return mulp


def add2(l1,l2):
	sum=[]
	for i in range(len(l1)):
		sum.append(l1[i]+l2[i])
	return sum

def sub2(l1,l2):
	diff=[]
	for i in range(len(l1)):
		diff.append(l1[i]-l2[i])
	return diff

def mul2(l1,l2):
	mulp=[]
	for i in range(len(l1)):
		mulp.append(l1[i]*l2[i])
	return mulp

def maxmin(l1):
	print (max(l1))
	print (min(l2))

def sort2(l1):
	l1.sort()
	return l1
