Swedict={
"merry":"god",
"christmas":"jul",
"and":"och",
"happy":"gott",
"new":"nytt",
"year":"ar"
}

def translate(*l1):
  l2=[]
  for x in l1[0]:
   
    b=Swedict[x]
    l2.append(b)
  print(l2)

lt=["merry","christmas"]
translate(lt)
