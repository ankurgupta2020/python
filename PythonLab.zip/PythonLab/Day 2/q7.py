flag=0
str1=input("Enter your string")
str1=str1.lower()
l=[]
for x in str1:
  num=ord(x)
  if num not in l: 
    l.append(num)

for x in range (97,123):
  if x not in l:
    flag=1
    print("Not Panagram")
    break
if flag==0:
  print("Panagram")
